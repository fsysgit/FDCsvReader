unit UnitMain;

interface

uses
  System.SysUtils, System.Types, System.UITypes, System.Classes, System.Variants,
  FMX.Types, FMX.Controls, FMX.Forms, FMX.Graphics, FMX.Dialogs, FMX.Memo.Types,
  FMX.Controls.Presentation, FMX.ScrollBox, FMX.Memo, FMX.StdCtrls,DateUtils,FS.FireDAC.CSVReader,
  FMX.ListBox,FireDAC.Stan.Intf;

type
  TForm1 = class(TForm)
    Memo1: TMemo;
    Button1: TButton;
    ComboBox1: TComboBox;
    Panel1: TPanel;
    Label1: TLabel;
    Label2: TLabel;
    ComboBox2: TComboBox;
    Memo2: TMemo;
    Label3: TLabel;
    Label4: TLabel;
    ComboBox3: TComboBox;
    CheckBox1: TCheckBox;
    CheckBox2: TCheckBox;
    ComboBox4: TComboBox;
    Label5: TLabel;
    procedure Button1Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    { private �錾 }
    csvReader : TFDCSVAnalyzer;
  public
    { public �錾 }
  end;

var
  Form1: TForm1;

implementation

{$R *.fmx}

procedure TForm1.Button1Click(Sender: TObject);
var
  i : integer;
  s : string;
  dt : TDateTime;
begin

  if (checkbox2.IsChecked) and (pos('large',Combobox1.text) > 0) then begin
    raise Exception.Create('can not be large csv and use export row.');
    exit;
  end;

  dt := now;

  if Combobox1.ItemIndex < 0 then exit;
  if Combobox2.ItemIndex < 0 then exit;
  if Combobox3.ItemIndex < 0 then exit;
  if combobox4.ItemIndex < 0 then exit;

  case Combobox4.ItemIndex of
    0 : csvReader.Encoding := ecANSI;
    1 : csvReader.Encoding := ecUTF8;
    2 : csvReader.Encoding := ecUTF16;
    3 : csvReader.Encoding := ecDefault;
  end;


  csvReader.WithFieldNames := TfsHeaderMode(Combobox2.ItemIndex);
  case Combobox3.ItemIndex of
    0 : csvReader.Separator := ',';
    1 : csvReader.Separator := #9;
  end;

  if csvReader.WithFieldNames = fhmManual then begin

    csvReader.SetFields(Memo2.lines.Text);
  end;

  csvReader.TruncateField := Checkbox1.IsChecked;

  csvReader.LoadCSV(combobox1.Text);
  csvReader.DataSet.First;
  s := '';
  For i := 0 to csvReader.DataSet.FieldCount - 1 do begin
    if s = '' then s := csvReader.DataSet.Fields[i].FieldName else s := s + '|' + csvReader.DataSet.Fields[i].FieldName;
  end;
  Memo1.lines.Add('-----' + Combobox1.Text + '-----');
  Memo1.lines.Add(s);
  Memo1.lines.Add(csvReader.DataSet.RecordCount.ToString + ' Rows Analyzed.');
  Memo1.lines.Add(FormatFloat('#,##0',MillisecondsBetween(now,dt)) + ' ms');
  if Checkbox2.IsChecked then begin
    csvReader.DataSet.First;
    while csvReader.DataSet.Eof = false do begin
      s := '';
      For i := 0 to csvReader.DataSet.FieldCount - 1 do begin
        if s = '' then s := csvReader.DataSet.Fields[i].AsWideString else s := s + '|' + csvReader.DataSet.Fields[i].AsWideString;
      end;
      Memo1.lines.Add(s);
      csvReader.DataSet.Next;
    end;
  end;
  Memo1.lines.Add('-----EOL-----');
end;

procedure TForm1.FormCreate(Sender: TObject);
begin
  csvReader := TFDCSVAnalyzer.Create(self);
end;

end.
